# ProtokollHandler für DokuWiki
## Description
The exec Protocol Handler in FF starts the Python program exec.py 
to execute local files (like MP3-files, PDF-files, or directories).

I use this protocoll handler in DokuWiki. I wrote a little PHP-plugin
which converts links to my "own" exec-protocoll

In DokuWiki 

<exec>$TEST\HelloWorld.txt</exec> 



